const preloader = document.querySelector(".preloader");

setTimeout(function() {
    preloader.remove();
}, 
//6700
500
); 